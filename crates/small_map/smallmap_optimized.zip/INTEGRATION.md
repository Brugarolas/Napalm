# SmallMap optimization overlay

These five files replace the identically named modules in the provided SmallMap project:

- `lib.rs` -> `src/lib.rs` (source upload was `lib(3).rs`)
- `inline.rs` -> `src/inline.rs`
- `set.rs` -> `src/set.rs`
- `util.rs` -> `src/raw/util.rs`
- `bitmask.rs` -> `src/raw/bitmask.rs`

Keep your existing `src/raw/mod.rs`, backend modules (`sse2.rs`, `avx2.rs`, `neon.rs`, `sve2.rs`, `generic.rs`), macros, serde integration, and Cargo.toml. They were not included in the upload and therefore cannot be included or compiled in this overlay. Do not replace the entire raw directory with these five files.

## Behavioral/architectural changes

- Control bytes remain compact with no group alignment: unsafe SIMD loads on partial tails are now made from fully initialized local scratch storage. Full groups still use the backend's native unaligned SIMD load.
- Inline map clearing now updates len before dropping each value, making a caught destructor panic safe from double drop; hashers are retained in place.
- Updating an existing key in a full inline map no longer spills to heap.
- Spill publishes a valid empty heap variant before allocation and rehashing. If hashing panics, the map remains usable but can lose entries during transfer (basic unwind guarantee, not strong).
- Heap growth factor on spill is ~1.5x instead of 2x; benchmark with realistic workloads.
- The default linear/SIMD threshold is fixed at 16 instead of depending on SIMD group width. The optimal threshold is workload-dependent and should be benchmarked.
- `SmallSet::replace` updates equivalent keys in place while inline. Heap mode keeps remove/reinsert behavior.
- BitMaskIter now implements ExactSizeIterator and FusedIterator, with backend-independent tests.
- Bucket<T> is Send only when T: Send; callers must still ensure correct lifetime and thread synchronization.
- Consuming inline iteration protects entries against hasher-drop panics.

## Verification

The environment lacks Rust toolchain (`cargo`, `rustc`, `rustfmt`), and the upload omitted raw backend modules plus Cargo.toml. Compilation and runtime tests **have not been executed**. New regression tests have been included in the modified files but require a complete project/toolchain.

Recommended checks:

```sh
cargo fmt --all -- --check
cargo test --all-features
cargo clippy --all-targets --all-features -- -D warnings
# Run targeted tests under a toolchain and target with AVX2 enabled, and on aarch64 with NEON / SVE2.
# Use cargo +nightly miri test when Miri is available for each supported target.
```

## Caveats

- Existing backend `Group::load` implementations must support unaligned loads (the previously supplied SSE2/AVX2/NEON/SVE2 examples do).
- The backend must expose `Group::LOWEST_MASK` with compatible packed/sparse mask representations and a `Group::WIDTH` matching its actual load width.
- This overlay intentionally does not rewrite `HashValue` into a separate dispatch architecture or add an allocation-heavy permanent padding field, since either change requires benchmarking.
- These are source-level improvements; no performance uplift is claimed without measurement.
